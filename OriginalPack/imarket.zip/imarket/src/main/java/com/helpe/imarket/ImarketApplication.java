package com.helpe.imarket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImarketApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImarketApplication.class, args);
	}
}
